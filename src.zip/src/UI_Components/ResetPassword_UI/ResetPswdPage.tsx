import React, { useState } from "react";

import {ParentContainer} from "./ParentContainer";
import {FormTop} from "./FormTop"
import {FormBottom} from "./FormBottom";

import { MainPageLayout } from "../Shared_Components/MainPageLyout"

export function ResetPasswordPage()
{
    const [emailString,setEmail] = useState("");

    return(
        <MainPageLayout>
            <ParentContainer>
                <header >
                    <h3 className="powerPingLogo"> <u>PowerPing01</u></h3>
                </header>

                <FormTop 
                    emailString = {emailString}
                    setEmail={(e)=>setEmail(e.target.value)}
                />

                <FormBottom 
                    emailValueEntered = {emailString}
                />
                
            </ParentContainer>
        </MainPageLayout>
        

        // 
    );
}