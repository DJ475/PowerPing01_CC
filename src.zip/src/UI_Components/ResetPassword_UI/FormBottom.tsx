import styles from "./FormBottom.module.css"

import {RegisterBtnContainer} from "./RegisterBtnContainer"


export function FormBottom()
{
    return(
        <div className={styles.example}>
            
            Implement Bottom Form Login Here

        </div>
    );
}