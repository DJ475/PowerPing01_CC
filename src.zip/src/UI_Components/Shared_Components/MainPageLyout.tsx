import { ReactNode } from "react"
import styles from "../Shared_Components/MainPageLayout.module.css"

type  MainPageProps = {
    children : ReactNode
}

export function MainPageLayout({children}: MainPageProps)
{
    return (
        <div className={styles.divMainPageLayout}>
            {children}
        </div>
    );
}